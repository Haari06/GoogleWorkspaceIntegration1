using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Flows;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Gmail.v1;
using Google.Apis.Gmail.v1.Data;
using Google.Apis.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using MimeKit;

namespace GoogleWorkspaceIntegration.Services
{
    public class GoogleSheetsService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;

        public GoogleSheetsService(IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
        {
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
        }

        public async Task<List<IList<object>>> GetFirstFiveRowsAsync(string spreadsheetId)
        {
            //var accessToken = await _httpContextAccessor.HttpContext.GetTokenAsync("access_token");
            var httpContext = _httpContextAccessor.HttpContext 
            ?? throw new InvalidOperationException("HTTP context not available");
            var accessToken = await httpContext.GetTokenAsync("access_token");
            
            var service = new SheetsService(new BaseClientService.Initializer
            {
                HttpClientInitializer = GoogleCredential.FromAccessToken(accessToken),
                ApplicationName = _configuration["Google:ApplicationName"]
            });

            // Specify the range to retrieve (first 5 rows from Sheet1)
            var range = "Sheet1!A1:Z5";
            var request = service.Spreadsheets.Values.Get(spreadsheetId, range);
            var response = await request.ExecuteAsync();
            
            return response.Values?.ToList() ?? new List<IList<object>>();
        }
    }

    public class GoogleGmailService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;

        public GoogleGmailService(IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
        {
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
        }

public async Task SendEmailAsync(string to, string subject, string body)
{
    var httpContext = _httpContextAccessor.HttpContext
        ?? throw new InvalidOperationException("HTTP context not available");

    var accessToken = await httpContext.GetTokenAsync("access_token");

    var service = new GmailService(new BaseClientService.Initializer
    {
        HttpClientInitializer = GoogleCredential.FromAccessToken(accessToken),
        ApplicationName = _configuration["Google:ApplicationName"]
    });

    // DEBUG: Log the incoming 'to' email value
    Console.WriteLine($"[SERVICE DEBUG] Raw 'to' value: '{to}'");

    // Validate recipient email
    to = (to ?? string.Empty).Trim();
    if (string.IsNullOrWhiteSpace(to))
    {
        throw new ArgumentException("Recipient email is required.");
    }

    MailboxAddress recipient;
    try
    {
        recipient = MailboxAddress.Parse(to);
    }
    catch (FormatException)
    {
        throw new ArgumentException("Invalid recipient email format.");
    }

    // Get sender email from authenticated user or fallback
    var userEmail = httpContext.User.FindFirst("email")?.Value 
                    ?? "hemanthvarahaa.dasari@gmail.com";

    var message = new MimeMessage();
    message.From.Add(new MailboxAddress("Me", userEmail));
    message.To.Add(recipient);
    message.Subject = string.IsNullOrWhiteSpace(subject) ? "(No Subject)" : subject;

    message.Body = new TextPart("plain")
    {
        Text = string.IsNullOrWhiteSpace(body) ? "(No Message Body)" : body
    };

    using var stream = new MemoryStream();
    await message.WriteToAsync(stream);
    stream.Position = 0;

    var gmail = new Message
    {
        Raw = Convert.ToBase64String(stream.ToArray())
            .Replace('+', '-')
            .Replace('/', '_')
            .Replace("=", "")
    };

    await service.Users.Messages.Send(gmail, "me").ExecuteAsync();
}

    }
}
