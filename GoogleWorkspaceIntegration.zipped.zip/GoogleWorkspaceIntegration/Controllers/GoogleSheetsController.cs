using GoogleWorkspaceIntegration.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace GoogleWorkspaceIntegration.Controllers
{
    [Authorize]
    public class GoogleSheetsController : Controller
    {
        private readonly GoogleSheetsService _sheetsService;
        private readonly IConfiguration _configuration;

        public GoogleSheetsController(GoogleSheetsService sheetsService, IConfiguration configuration)
        {
            _sheetsService = sheetsService;
            _configuration = configuration;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            try
            {
                // Get spreadsheet ID from config (or you can make this configurable)
                var spreadsheetId = _configuration["Google:SpreadsheetId"];
                if (string.IsNullOrWhiteSpace(spreadsheetId))
                {
                    throw new InvalidOperationException("Spreadsheet ID is missing from configuration.");
                }
                // Get first 5 rows from the sheet
                var rows = await _sheetsService.GetFirstFiveRowsAsync(spreadsheetId);
                
                return View(rows);
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Error retrieving sheet data: {ex.Message}";
                return View(new List<IList<object>>());
            }
        }
    }
}
