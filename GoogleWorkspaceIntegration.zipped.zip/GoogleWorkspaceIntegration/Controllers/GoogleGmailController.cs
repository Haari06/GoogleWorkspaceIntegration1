using GoogleWorkspaceIntegration.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace GoogleWorkspaceIntegration.Controllers
{
    [Authorize]
    public class GoogleGmailController : Controller
    {
        private readonly GoogleGmailService _gmailService;

        public GoogleGmailController(GoogleGmailService gmailService)
        {
            _gmailService = gmailService;
        }

        [HttpGet]
        public IActionResult SendEmail()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> SendEmail(string to, string subject, string body)
        {
            try
            {
                await _gmailService.SendEmailAsync(to, subject, body);
                ViewBag.Success = "Email sent successfully!";
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Error sending email: {ex.Message}";
            }
            
            return View();
        }
    }
}
